function arrayFinder(x, n) {

}
console.log(arrayFinder(3, 4))