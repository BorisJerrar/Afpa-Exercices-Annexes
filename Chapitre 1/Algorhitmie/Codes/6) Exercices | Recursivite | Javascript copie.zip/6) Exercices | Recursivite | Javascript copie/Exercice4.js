
let n = 345
let array = [...n+""]
let result = 0
array.map(value => result += +value)


console.log(result)

